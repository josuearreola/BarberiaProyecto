import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Delete,
  Patch,
  HttpCode,
  HttpStatus,
  Query,
  UseGuards,
  Req,
  Headers,
} from '@nestjs/common';
import { AppointmentsService } from './appointments.service';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { UpdateAppointmentDto } from './dto/update-appointment.dto';
import { UpdateStatusDto } from './dto/update-status.dto';
import { SessionAuthGuard } from '../auth/guards/session-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';

@Controller('appointments')
export class AppointmentsController {
  private readonly idempotencyCache = new Map<
    string,
    { value: unknown; expiresAt: number }
  >();
  private readonly inFlightCreates = new Map<string, Promise<unknown>>();

  constructor(private readonly appointmentsService: AppointmentsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(
    @Body() createAppointmentDto: CreateAppointmentDto,
    @Headers('idempotency-key') idempotencyKey?: string,
  ) {
    const key = idempotencyKey?.trim();
    if (key) {
      const now = Date.now();
      const cached = this.idempotencyCache.get(key);
      if (cached && cached.expiresAt > now) {
        return cached.value;
      }
      const pending = this.inFlightCreates.get(key);
      if (pending) {
        return pending;
      }

      const work = (async () => {
        const created =
          await this.appointmentsService.create(createAppointmentDto);
        this.appointmentsService.invalidateDateCache(
          createAppointmentDto.fechaCita,
        );
        if (this.idempotencyCache.size > 500) {
          this.idempotencyCache.clear();
        }
        this.idempotencyCache.set(key, {
          value: created,
          expiresAt: Date.now() + 5 * 60 * 1000,
        });
        return created;
      })();

      this.inFlightCreates.set(key, work);
      try {
        return await work;
      } finally {
        this.inFlightCreates.delete(key);
      }
    }

    const created = await this.appointmentsService.create(createAppointmentDto);
    this.appointmentsService.invalidateDateCache(createAppointmentDto.fechaCita);
    return created;
  }

  @Post('audio-presigned-url')
  getAudioPresignedUrl(@Req() req: any, @Body() body: { fileName?: string }) {
    const host = req.get('host');
    const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    return this.appointmentsService.generateAudioPresignedUrl(
      body?.fileName,
      `${protocol}://${host}`,
    );
  }

  @Put('upload-audio')
  async uploadAudio(
    @Query('fileName') fileName: string,
    @Query('expires') expires: string,
    @Query('signature') signature: string,
    @Req() req: any,
  ) {
    const buffer = req.body;
    return this.appointmentsService.saveUploadedAudio(
      fileName,
      expires,
      signature,
      buffer,
    );
  }

  // Ruta PÚBLICA para que la TV PWA pueda cargar citas del día sin autenticación
  @Get('by-date/:fecha')
  findByDatePublic(@Param('fecha') fecha: string) {
    return this.appointmentsService.findByDate(fecha);
  }

  @Get('mis-citas')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Cliente, UserRole.Admin)
  findMyAppointments(@Req() request: any) {
    const userId = request.session?.userId;
    return this.appointmentsService.findClientAppointments(userId);
  }

  @Patch('mis-citas/:id/cancelar')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Cliente)
  async cancelMyAppointment(@Param('id') id: string, @Req() request: any) {
    const userId = request.session?.userId;
    return this.appointmentsService.cancelClientAppointment(+id, userId);
  }

  @Get()
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  findAll(
    @Query('fecha') fecha?: string,
    @Query('estado') estado?: string,
    @Query('search') search?: string,
    @Query('sortBy') sortBy?: string,
    @Query('sortDir') sortDir?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ): Promise<unknown> {
    return this.appointmentsService.findAll({
      fecha,
      estado,
      search,
      sortBy,
      sortDir,
      page: Number(page),
      limit: Number(limit),
    });
  }

  @Get(':id')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  findOne(@Param('id') id: string) {
    return this.appointmentsService.findOne(+id);
  }

  @Get('fecha/:fecha')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  findByDate(@Param('fecha') fecha: string) {
    return this.appointmentsService.findByDate(fecha);
  }

  @Patch(':id/estado')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  updateStatus(@Param('id') id: string, @Body() body: UpdateStatusDto) {
    return this.appointmentsService.updateStatus(+id, body.estado, body.nombreBarbero);
  }

  @Patch(':id')
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  update(
    @Param('id') id: string,
    @Body() updateAppointmentDto: UpdateAppointmentDto,
  ) {
    return this.appointmentsService.update(+id, updateAppointmentDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @UseGuards(SessionAuthGuard, RolesGuard)
  @Roles(UserRole.Admin)
  remove(@Param('id') id: string) {
    return this.appointmentsService.remove(+id);
  }
}
